-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creature_id` bigint(20) unsigned NOT NULL,
  `creature_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `range` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `attack` tinyint(1) NOT NULL DEFAULT '0',
  `attack_modifier` int(11) DEFAULT NULL,
  `attack_does_damage` tinyint(1) NOT NULL DEFAULT '0',
  `attack_dice` json DEFAULT NULL,
  `save` tinyint(1) NOT NULL DEFAULT '0',
  `save_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `save_dc` int(11) DEFAULT NULL,
  `save_does_damage` tinyint(1) NOT NULL DEFAULT '0',
  `save_dice` json DEFAULT NULL,
  `auto` tinyint(1) NOT NULL DEFAULT '0',
  `auto_does_damage` tinyint(1) NOT NULL DEFAULT '0',
  `auto_dice` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES (1,'2021-10-28 01:05:25','2021-11-22 13:26:52','Icethorn Dagger',1,'App\\Models\\Character','Action','5 ft.',NULL,1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 2}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(2,'2021-10-28 01:05:25','2021-10-28 01:05:25','Dissonant Whispers',1,'App\\Models\\Character','Action','30 ft.',NULL,0,NULL,0,NULL,1,'WIS',13,1,'[{\"size\": 6, \"type\": \"Psychic\", \"count\": 3, \"modifier\": 0}]',0,0,NULL),(3,'2021-10-28 01:05:25','2021-10-28 01:05:25','Bite',1,'App\\Models\\Monster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(4,'2021-10-28 01:05:26','2021-10-28 01:05:26','Bite',1,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(5,'2021-10-28 01:05:26','2021-10-28 01:05:26','Bite',2,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(7,'2021-10-30 11:19:45','2021-10-30 15:04:32','Ray of Frost',1,'App\\Models\\Character','Action','60 ft.','On a hit, the target\'s speed is reduced by 10 feet until the start of your next turn.',1,5,1,'[{\"size\": 8, \"type\": \"Cold\", \"count\": 1, \"modifier\": 0}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(9,'2021-10-30 16:34:57','2021-10-30 16:34:57','Bite',4,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(10,'2021-10-30 16:34:57','2021-10-30 16:34:57','Bite',5,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(11,'2021-10-30 16:34:58','2021-10-30 16:34:58','Bite',6,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(12,'2021-11-14 14:55:05','2021-11-14 14:55:05','Bite',7,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(22,'2021-11-14 15:09:05','2021-11-14 15:09:05','Bite',17,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(23,'2021-11-14 15:09:10','2021-11-14 15:09:10','Bite',18,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(24,'2021-11-14 15:09:12','2021-11-14 15:09:12','Bite',19,'App\\Models\\EncounterMonster','Action','5 ft.','If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.',1,4,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 2, \"modifier\": 2}]',0,NULL,NULL,0,NULL,0,0,NULL),(25,'2021-11-21 03:21:02','2021-11-21 03:21:19','Bite',2,'App\\Models\\Monster','Action','5 ft',NULL,1,7,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 4}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(26,'2021-11-21 03:22:15','2021-11-21 03:22:15','Claw',2,'App\\Models\\Monster','Action','5 ft',NULL,1,7,1,'[{\"size\": 6, \"type\": \"Slashing\", \"count\": 2, \"modifier\": 4}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(28,'2021-11-21 03:34:29','2021-11-21 03:34:29','Shortsword',4,'App\\Models\\Monster','Action','5 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(29,'2021-11-21 03:34:56','2021-11-21 03:34:56','Shortbow',4,'App\\Models\\Monster','Action','80/320 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(30,'2021-11-21 03:37:28','2021-11-21 03:37:28','Scimitar',5,'App\\Models\\Monster','Action','5 ft.',NULL,1,4,1,'[{\"size\": 6, \"type\": \"Slashing\", \"count\": 1, \"modifier\": 2}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(31,'2021-11-21 03:37:48','2021-11-21 03:37:48','Shortbow',5,'App\\Models\\Monster','Action','80/320 ft',NULL,1,4,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 2}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(34,'2021-11-21 03:39:20','2021-11-21 03:39:20','Blood Drain',21,'App\\Models\\EncounterMonster','Action','5 ft','On a hit, the stirge attaches to the target. While attached, the stirge doesn\'t attack. Instead, at the start of each of the stirge\'s turns, the target loses 5 (1d4 + 3) hit points due to blood loss.\n\nThe stirge can detach itself by spending 5 feet of its movement. It does so after it drains 10 hit points of blood from the target or the target dies. A creature, including the target, can use its action to detach the stirge.',1,5,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(35,'2021-11-21 03:39:20','2021-11-21 03:39:20','Blood Drain',22,'App\\Models\\EncounterMonster','Action','5 ft','On a hit, the stirge attaches to the target. While attached, the stirge doesn\'t attack. Instead, at the start of each of the stirge\'s turns, the target loses 5 (1d4 + 3) hit points due to blood loss.\n\nThe stirge can detach itself by spending 5 feet of its movement. It does so after it drains 10 hit points of blood from the target or the target dies. A creature, including the target, can use its action to detach the stirge.',1,5,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(36,'2021-11-21 03:39:21','2021-11-21 03:39:21','Blood Drain',23,'App\\Models\\EncounterMonster','Action','5 ft','On a hit, the stirge attaches to the target. While attached, the stirge doesn\'t attack. Instead, at the start of each of the stirge\'s turns, the target loses 5 (1d4 + 3) hit points due to blood loss.\n\nThe stirge can detach itself by spending 5 feet of its movement. It does so after it drains 10 hit points of blood from the target or the target dies. A creature, including the target, can use its action to detach the stirge.',1,5,1,'[{\"size\": 4, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(37,'2021-11-21 03:40:27','2021-11-21 03:40:27','Shortbow',24,'App\\Models\\EncounterMonster','Action','80/320 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(38,'2021-11-21 03:40:27','2021-11-21 03:40:27','Shortsword',24,'App\\Models\\EncounterMonster','Action','5 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(39,'2021-11-21 03:40:28','2021-11-21 03:40:28','Shortbow',25,'App\\Models\\EncounterMonster','Action','80/320 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(40,'2021-11-21 03:40:28','2021-11-21 03:40:28','Shortsword',25,'App\\Models\\EncounterMonster','Action','5 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(41,'2021-11-21 03:40:28','2021-11-21 03:40:28','Shortbow',26,'App\\Models\\EncounterMonster','Action','80/320 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(42,'2021-11-21 03:40:28','2021-11-21 03:40:28','Shortsword',26,'App\\Models\\EncounterMonster','Action','5 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(43,'2021-11-21 03:40:28','2021-11-21 03:40:28','Shortbow',27,'App\\Models\\EncounterMonster','Action','80/320 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(44,'2021-11-21 03:40:28','2021-11-21 03:40:28','Shortsword',27,'App\\Models\\EncounterMonster','Action','5 ft',NULL,1,5,1,'[{\"size\": 6, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 3}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(45,'2021-11-21 04:04:27','2021-11-21 04:04:27','Halberd',6,'App\\Models\\Monster','Action','10 ft.',NULL,1,6,1,'[{\"size\": 10, \"type\": \"Slashing\", \"count\": 1, \"modifier\": 4}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(46,'2021-11-21 04:04:56','2021-11-21 04:04:56','Heavy Crossbow',6,'App\\Models\\Monster','Action','100/400',NULL,1,4,1,'[{\"size\": 10, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 2}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(47,'2021-11-21 04:11:34','2021-11-21 04:13:07','Loyal Bodyguard',6,'App\\Models\\Monster','Reaction','5 ft.','When another fiend within 5 feet of the merregon is hit by an attack, the merregon causes itself to be hit instead.',0,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',1,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(48,'2021-11-21 04:11:44','2021-11-21 04:11:44','Halberd',28,'App\\Models\\EncounterMonster','Action','10 ft.',NULL,1,6,1,'[{\"size\": 10, \"type\": \"Slashing\", \"count\": 1, \"modifier\": 4}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(49,'2021-11-21 04:11:44','2021-11-21 04:11:44','Heavy Crossbow',28,'App\\Models\\EncounterMonster','Action','100/400',NULL,1,4,1,'[{\"size\": 10, \"type\": \"Piercing\", \"count\": 1, \"modifier\": 2}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]'),(50,'2021-11-21 04:11:44','2021-11-21 04:12:11','Loyal Bodyguard',28,'App\\Models\\EncounterMonster','Reaction','5 ft.','When another fiend within 5 feet of the merregon is hit by an attack, the merregon causes itself to be hit instead.',0,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',0,NULL,NULL,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]',1,0,'[{\"size\": 0, \"type\": null, \"count\": 0, \"modifier\": 0}]');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hp_max` int(11) NOT NULL DEFAULT '0',
  `hp_current` int(11) NOT NULL DEFAULT '0',
  `hp_temp` int(11) NOT NULL DEFAULT '0',
  `hit_dice` json DEFAULT NULL,
  `ac` int(11) NOT NULL DEFAULT '0',
  `ac_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initiative` int(11) NOT NULL DEFAULT '0',
  `speed` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `strength` int(11) NOT NULL DEFAULT '0',
  `strength_mod` int(11) NOT NULL DEFAULT '0',
  `strength_save` int(11) NOT NULL DEFAULT '0',
  `strength_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `athletics` int(11) NOT NULL DEFAULT '0',
  `athletics_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `athletics_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `dexterity` int(11) NOT NULL DEFAULT '0',
  `dexterity_mod` int(11) NOT NULL DEFAULT '0',
  `dexterity_save` int(11) NOT NULL DEFAULT '0',
  `dexterity_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `acrobatics` int(11) NOT NULL DEFAULT '0',
  `acrobatics_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `acrobatics_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `sleight_of_hand` int(11) NOT NULL DEFAULT '0',
  `sleight_of_hand_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `sleight_of_hand_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `stealth` int(11) NOT NULL DEFAULT '0',
  `stealth_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `stealth_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `constitution` int(11) NOT NULL DEFAULT '0',
  `constitution_mod` int(11) NOT NULL DEFAULT '0',
  `constitution_save` int(11) NOT NULL DEFAULT '0',
  `constitution_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `intelligence` int(11) NOT NULL DEFAULT '0',
  `intelligence_mod` int(11) NOT NULL DEFAULT '0',
  `intelligence_save` int(11) NOT NULL DEFAULT '0',
  `intelligence_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `arcana` int(11) NOT NULL DEFAULT '0',
  `arcana_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `arcana_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `history` int(11) NOT NULL DEFAULT '0',
  `history_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `history_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `investigation` int(11) NOT NULL DEFAULT '0',
  `investigation_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `investigation_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `nature` int(11) NOT NULL DEFAULT '0',
  `nature_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `nature_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `religion` int(11) NOT NULL DEFAULT '0',
  `religion_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `religion_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `wisdom` int(11) NOT NULL DEFAULT '0',
  `wisdom_mod` int(11) NOT NULL DEFAULT '0',
  `wisdom_save` int(11) NOT NULL DEFAULT '0',
  `wisdom_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `animal_handling` int(11) NOT NULL DEFAULT '0',
  `animal_handling_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `animal_handling_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `insight` int(11) NOT NULL DEFAULT '0',
  `insight_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `insight_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `medicine` int(11) NOT NULL DEFAULT '0',
  `medicine_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `medicine_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `perception` int(11) NOT NULL DEFAULT '0',
  `perception_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `perception_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `survival` int(11) NOT NULL DEFAULT '0',
  `survival_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `survival_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `charisma` int(11) NOT NULL DEFAULT '0',
  `charisma_mod` int(11) NOT NULL DEFAULT '0',
  `charisma_save` int(11) NOT NULL DEFAULT '0',
  `charisma_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `deception` int(11) NOT NULL DEFAULT '0',
  `deception_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `deception_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `intimidation` int(11) NOT NULL DEFAULT '0',
  `intimidation_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `intimidation_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `performance` int(11) NOT NULL DEFAULT '0',
  `performance_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `performance_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `persuasion` int(11) NOT NULL DEFAULT '0',
  `persuasion_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `persuasion_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `skills_auto_filled` tinyint(1) NOT NULL DEFAULT '1',
  `skill_modifiers` json DEFAULT NULL,
  `spellcaster` tinyint(1) NOT NULL DEFAULT '0',
  `spell_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'slots',
  `spell_dc` int(11) DEFAULT NULL,
  `spell_level` int(11) DEFAULT NULL,
  `spell_points_max` int(11) DEFAULT NULL,
  `spell_points_current` int(11) DEFAULT NULL,
  `spell_recover` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'long',
  `spell_list_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'known',
  `spell_slots_1` json DEFAULT NULL,
  `spell_slots_2` json DEFAULT NULL,
  `spell_slots_3` json DEFAULT NULL,
  `spell_slots_4` json DEFAULT NULL,
  `spell_slots_5` json DEFAULT NULL,
  `spell_slots_6` json DEFAULT NULL,
  `spell_slots_7` json DEFAULT NULL,
  `spell_slots_8` json DEFAULT NULL,
  `spell_slots_9` json DEFAULT NULL,
  `spell_list_0` json DEFAULT NULL,
  `spell_list_1` json DEFAULT NULL,
  `spell_list_2` json DEFAULT NULL,
  `spell_list_3` json DEFAULT NULL,
  `spell_list_4` json DEFAULT NULL,
  `spell_list_5` json DEFAULT NULL,
  `spell_list_6` json DEFAULT NULL,
  `spell_list_7` json DEFAULT NULL,
  `spell_list_8` json DEFAULT NULL,
  `spell_list_9` json DEFAULT NULL,
  `spell_prepare_count` int(11) DEFAULT NULL,
  `spell_prepared` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `show_resources` tinyint(1) NOT NULL DEFAULT '1',
  `show_modifiers` tinyint(1) NOT NULL DEFAULT '1',
  `show_notes` tinyint(1) NOT NULL DEFAULT '1',
  `show_dice` tinyint(1) NOT NULL DEFAULT '1',
  `show_additional_stats` tinyint(1) NOT NULL DEFAULT '1',
  `show_temp_hp` tinyint(1) NOT NULL DEFAULT '1',
  `damage_vulnerabilities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_resistances` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_immunities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition_immunities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senses` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `race` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `archive_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `characters_user_id_foreign` (`user_id`),
  CONSTRAINT `characters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (1,'2021-10-28 01:05:25','2021-11-22 14:39:07',1,'Landrin',31,31,0,'[{\"size\": 8, \"count\": 4, \"current\": 4}]',14,'studded leather armor',3,'30 ft.',8,0,-1,0,0,0,0,14,3,4,1,3,0,0,3,0,0,3,0,0,14,3,2,0,12,2,1,0,3,1,0,5,1,1,3,1,0,2,0,0,2,0,0,12,2,1,0,2,0,0,2,0,0,2,0,0,2,0,0,3,1,0,18,5,6,1,6,1,0,5,0,0,6,1,0,8,1,1,1,'[\"jack_of_all_trades\"]',1,'slots',14,NULL,NULL,NULL,'long','known','[false, false, false, false]','[false, false, false]','[]','[]','[]','[]','[]','[]','[]','[\"Mage Hand (60 ft.)\", \"Ray of Frost\", \"Shape Water\"]','[\"Charm Person\", \"Dissonant Whispers\", \"Faerie Fire\", \"Tasha\'s Hideous Laughter\"]','[\"Blindness/Deafness\", \"Invisibility\", \"Suggestion\"]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'insp leader temp: 8',1,1,1,1,0,1,NULL,NULL,NULL,NULL,'Common',NULL,'human','bard',4,NULL);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dice_tables`
--

DROP TABLE IF EXISTS `dice_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dice_tables` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rows` json NOT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `dice_tables_user_id_foreign` (`user_id`),
  CONSTRAINT `dice_tables_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dice_tables`
--

LOCK TABLES `dice_tables` WRITE;
/*!40000 ALTER TABLE `dice_tables` DISABLE KEYS */;
INSERT INTO `dice_tables` VALUES (1,'2021-10-28 01:05:26','2021-10-28 01:05:26',1,'Wild Magic','[{\"range\": [1, 2], \"result\": \"Roll on this table at the start of each of your turns for the next minute, ignoring this result on subsequent rolls.\"}, {\"range\": [3, 4], \"result\": \"For the next minute, you can see any invisible creature if you have line of sight to it.\"}, {\"range\": [5, 6], \"result\": \"A modron chosen and controlled by the DM appears in an unoccupied space within 5 feet of you, then disappears 1 minute later.\"}, {\"range\": [7, 8], \"result\": \"You cast fireball as a 3rd-level spell centered on yourself.\"}, {\"range\": [9, 10], \"result\": \"You cast magic missile as a 5th-level spell.\"}, {\"range\": [11, 12], \"result\": \"Roll a d10. Your height changes by a number of inches equal to the roll. If the roll is odd, you shrink. If the roll is even, you grow.\"}, {\"range\": [13, 14], \"result\": \"You cast confusion centered on yourself.\"}, {\"range\": [15, 16], \"result\": \"For the next minute, you regain 5 hit points at the start of each of your turns.\"}, {\"range\": [17, 18], \"result\": \"You grow a long beard made of feathers that remains until you sneeze, at which point the feathers explode out from your face.\"}, {\"range\": [19, 20], \"result\": \"You cast grease centered on yourself.\"}, {\"range\": [21, 22], \"result\": \"Creatures have disadvantage on saving throws against the next spell you cast in the next minute that involves a saving throw.\"}, {\"range\": [23, 24], \"result\": \"Your skin turns a vibrant shade of blue. A remove curse spell can end this effect.\"}, {\"range\": [25, 26], \"result\": \"An eye appears on your forehead for the next minute.\"}, {\"range\": [27, 28], \"result\": \"For the next minute, all your spells with a casting time of 1 action have a casting time of 1 bonus action.\"}, {\"range\": [29, 30], \"result\": \"You teleport up to 60 feet to an unoccupied space of your choice that you can see.\"}, {\"range\": [31, 32], \"result\": \"You are transported to the Astral Plane until the end of your next turn, after which time you return to the space you previously occupied or the nearest unoccupied space if that space is occupied.\"}, {\"range\": [33, 34], \"result\": \"Maximize the damage of the next damaging spell you cast within the next minute.\"}, {\"range\": [35, 36], \"result\": \"Roll a d10. Your age changes by a number of years equal to the roll. If the roll is odd, you get younger (minimum 1 year old). If the roll is even, you get older.\"}, {\"range\": [37, 38], \"result\": \"1d6 flumphs controlled by the DM appear in unoccupied spaces within 60 feet of you and are frightened of you. They vanish after 1 minute.\"}, {\"range\": [39, 40], \"result\": \"You regain 2d10 hit points.\"}, {\"range\": [41, 42], \"result\": \"You turn into a potted plant until the start of your next turn. While a plant, you are incapacitated and have vulnerability to all damage. If you drop to 0 hit points, your pot breaks, and your form reverts.\"}, {\"range\": [43, 44], \"result\": \"For the next minute, you can teleport up to 20 feet as a bonus action on each of your turns.\"}, {\"range\": [45, 46], \"result\": \"You cast levitate on yourself.\"}, {\"range\": [47, 48], \"result\": \"A unicorn controlled by the DM appears in a space within 5 feet of you, then disappears 1 minute later.\"}, {\"range\": [49, 50], \"result\": \"You can\'t speak for the next minute. Whenever you try, pink bubbles float out of your mouth.\"}, {\"range\": [51, 52], \"result\": \"A spectral shield hovers near you for the next minute, granting you a +2 bonus to AC and immunity to magic missile.\"}, {\"range\": [53, 54], \"result\": \"You are immune to being intoxicated by alcohol for the next 5d6 days.\"}, {\"range\": [55, 56], \"result\": \"Your hair falls out but grows back within 24 hours.\"}, {\"range\": [57, 58], \"result\": \"For the next minute, any flammable object you touch that isn\'t being worn or carried by another creature bursts into flame.\"}, {\"range\": [59, 60], \"result\": \"You regain your lowest-level expended spell slot.\"}, {\"range\": [61, 62], \"result\": \"For the next minute, you must shout when you speak.\"}, {\"range\": [63, 64], \"result\": \"You cast fog cloud centered on yourself.\"}, {\"range\": [65, 66], \"result\": \"Up to three creatures you choose within 30 feet of you take 4d10 lightning damage.\"}, {\"range\": [67, 68], \"result\": \"You are frightened by the nearest creature until the end of your next turn.\"}, {\"range\": [69, 70], \"result\": \"Each creature within 30 feet of you becomes invisible for the next minute. The invisibility ends on a creature when it attacks or casts a spell.\"}, {\"range\": [71, 72], \"result\": \"You gain resistance to all damage for the next minute.\"}, {\"range\": [73, 74], \"result\": \"A random creature within 60 feet of you becomes poisoned for 1d4 hours.\"}, {\"range\": [75, 76], \"result\": \"You glow with bright light in a 30-foot radius for the next minute. Any creature that ends its turn within 5 feet of you is blinded until the end of its next turn.\"}, {\"range\": [77, 78], \"result\": \"You cast polymorph on yourself. If you fail the saving throw, you turn into a sheep for the spell\'s duration.\"}, {\"range\": [79, 80], \"result\": \"Illusory butterflies and flower petals flutter in the air within 10 feet of you for the next minute.\"}, {\"range\": [81, 82], \"result\": \"You can take one additional action immediately.\"}, {\"range\": [83, 84], \"result\": \"Each creature within 30 feet of you takes 1d10 necrotic damage. You regain hit points equal to the sum of the necrotic damage dealt.\"}, {\"range\": [85, 86], \"result\": \"You cast mirror image.\"}, {\"range\": [87, 88], \"result\": \"You cast fly on a random creature within 60 feet of you.\"}, {\"range\": [89, 90], \"result\": \"You become invisible for the next minute. During that time, other creatures can\'t hear you. The invisibility ends if you attack or cast a spell.\"}, {\"range\": [91, 92], \"result\": \"If you die within the next minute, you immediately come back to life as if by the reincarnate spell.\"}, {\"range\": [93, 94], \"result\": \"Your size increases by one size category for the next minute.\"}, {\"range\": [95, 96], \"result\": \"You and all creatures within 30 feet of you gain vulnerability to piercing damage for the next minute.\"}, {\"range\": [97, 98], \"result\": \"You are surrounded by faint, ethereal music for the next minute.\"}, {\"range\": [99, 100], \"result\": \"You regain all expended sorcery points.\"}]',1),(4,'2021-11-21 03:47:31','2021-11-21 03:47:31',1,'Trinket','[{\"range\": [1], \"result\": \"A mummified goblin hand\"}, {\"range\": [2], \"result\": \"A piece of crystal that faintly glows in the moonlight\"}, {\"range\": [3], \"result\": \"A gold coin minted in an unknown land\"}, {\"range\": [4], \"result\": \"A diary written in a language you don\'t know\"}, {\"range\": [5], \"result\": \"A brass ring that never tarnishes\"}, {\"range\": [6], \"result\": \"An old chess piece made from glass\"}, {\"range\": [7], \"result\": \"A pair of knucklebone dice, each with a skull symbol on the side that would normally show six pips\"}, {\"range\": [8], \"result\": \"A small idol depicting a nightmarish creature that gives you unsettling dreams when you sleep near it\"}, {\"range\": [9], \"result\": \"A rope necklace from which dangles four mummified elf fingers\"}, {\"range\": [10], \"result\": \"The deed for a parcel of land in a realm unknown to you\"}, {\"range\": [11], \"result\": \"A 1-ounce block made from an unknown material\"}, {\"range\": [12], \"result\": \"A small cloth doll skewered with needles\"}, {\"range\": [13], \"result\": \"A tooth from an unknown beast\"}, {\"range\": [14], \"result\": \"An enormous scale, perhaps from a dragon\"}, {\"range\": [15], \"result\": \"A bright green feather\"}, {\"range\": [16], \"result\": \"An old divination card bearing your likeness\"}, {\"range\": [17], \"result\": \"A glass orb filled with moving smoke\"}, {\"range\": [18], \"result\": \"A 1-pound egg with a bright red shell\"}, {\"range\": [19], \"result\": \"A pipe that blows bubbles\"}, {\"range\": [20], \"result\": \"A glass jar containing a weird bit of flesh floating in pickling fluid\"}, {\"range\": [21], \"result\": \"A tiny gnome-crafted music box that plays a song you dimly remember from your childhood\"}, {\"range\": [22], \"result\": \"A small wooden statuette of a smug halfling\"}, {\"range\": [23], \"result\": \"A brass orb etched with strange runes\"}, {\"range\": [24], \"result\": \"A multicolored stone disk\"}, {\"range\": [25], \"result\": \"A tiny silver icon of a raven\"}, {\"range\": [26], \"result\": \"A bag containing forty-seven humanoid teeth, one of which is rotten\"}, {\"range\": [27], \"result\": \"A shard of obsidian that always feels warm to the touch\"}, {\"range\": [28], \"result\": \"A dragon\'s bony talon hanging from a plain leather necklace\"}, {\"range\": [29], \"result\": \"A pair of old socks\"}, {\"range\": [30], \"result\": \"A blank book whose pages refuse to hold ink, chalk, graphite, or any other substance or marking\"}, {\"range\": [31], \"result\": \"A silver badge in the shape of a five-pointed star\"}, {\"range\": [32], \"result\": \"A knife that belonged to a relative\"}, {\"range\": [33], \"result\": \"A glass vial filled with nail clippings\"}, {\"range\": [34], \"result\": \"A rectangular metal device with two tiny metal cups on one end that throws sparks when wet\"}, {\"range\": [35], \"result\": \"A white, sequined glove sized for a human\"}, {\"range\": [36], \"result\": \"A vest with one hundred tiny pockets\"}, {\"range\": [37], \"result\": \"A small, weightless stone block\"}, {\"range\": [38], \"result\": \"A tiny sketch portrait of a goblin\"}, {\"range\": [39], \"result\": \"An empty glass vial that smells of perfume when opened\"}, {\"range\": [40], \"result\": \"A gemstone that looks like a lump of coal when examined by anyone but you\"}, {\"range\": [41], \"result\": \"A scrap of cloth from an old banner\"}, {\"range\": [42], \"result\": \"A rank insignia from a lost legionnaire\"}, {\"range\": [43], \"result\": \"A tiny silver bell without a clapper\"}, {\"range\": [44], \"result\": \"A mechanical canary inside a gnomish lamp\"}, {\"range\": [45], \"result\": \"A tiny chest carved to look like it has numerous feet on the bottom\"}, {\"range\": [46], \"result\": \"A dead sprite inside a clear glass bottle\"}, {\"range\": [47], \"result\": \"A metal can that has no opening but sounds as if it is filled with liquid, sand, spiders, or broken glass (your choice)\"}, {\"range\": [48], \"result\": \"A glass orb filled with water, in which swims a clockwork goldfish\"}, {\"range\": [49], \"result\": \"A silver spoon with an \'M\' engraved on the handle\"}, {\"range\": [50], \"result\": \"A whistle made from gold-colored wood\"}]',1);
/*!40000 ALTER TABLE `dice_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter_monsters`
--

DROP TABLE IF EXISTS `encounter_monsters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `encounter_monsters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hp_max` int(11) NOT NULL DEFAULT '0',
  `hp_current` int(11) NOT NULL DEFAULT '0',
  `hp_temp` int(11) NOT NULL DEFAULT '0',
  `hit_dice` json DEFAULT NULL,
  `ac` int(11) NOT NULL DEFAULT '0',
  `ac_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initiative` int(11) NOT NULL DEFAULT '0',
  `speed` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `strength` int(11) NOT NULL DEFAULT '0',
  `strength_mod` int(11) NOT NULL DEFAULT '0',
  `strength_save` int(11) NOT NULL DEFAULT '0',
  `strength_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `athletics` int(11) NOT NULL DEFAULT '0',
  `athletics_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `athletics_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `dexterity` int(11) NOT NULL DEFAULT '0',
  `dexterity_mod` int(11) NOT NULL DEFAULT '0',
  `dexterity_save` int(11) NOT NULL DEFAULT '0',
  `dexterity_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `acrobatics` int(11) NOT NULL DEFAULT '0',
  `acrobatics_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `acrobatics_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `sleight_of_hand` int(11) NOT NULL DEFAULT '0',
  `sleight_of_hand_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `sleight_of_hand_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `stealth` int(11) NOT NULL DEFAULT '0',
  `stealth_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `stealth_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `constitution` int(11) NOT NULL DEFAULT '0',
  `constitution_mod` int(11) NOT NULL DEFAULT '0',
  `constitution_save` int(11) NOT NULL DEFAULT '0',
  `constitution_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `intelligence` int(11) NOT NULL DEFAULT '0',
  `intelligence_mod` int(11) NOT NULL DEFAULT '0',
  `intelligence_save` int(11) NOT NULL DEFAULT '0',
  `intelligence_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `arcana` int(11) NOT NULL DEFAULT '0',
  `arcana_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `arcana_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `history` int(11) NOT NULL DEFAULT '0',
  `history_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `history_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `investigation` int(11) NOT NULL DEFAULT '0',
  `investigation_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `investigation_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `nature` int(11) NOT NULL DEFAULT '0',
  `nature_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `nature_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `religion` int(11) NOT NULL DEFAULT '0',
  `religion_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `religion_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `wisdom` int(11) NOT NULL DEFAULT '0',
  `wisdom_mod` int(11) NOT NULL DEFAULT '0',
  `wisdom_save` int(11) NOT NULL DEFAULT '0',
  `wisdom_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `animal_handling` int(11) NOT NULL DEFAULT '0',
  `animal_handling_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `animal_handling_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `insight` int(11) NOT NULL DEFAULT '0',
  `insight_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `insight_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `medicine` int(11) NOT NULL DEFAULT '0',
  `medicine_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `medicine_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `perception` int(11) NOT NULL DEFAULT '0',
  `perception_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `perception_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `survival` int(11) NOT NULL DEFAULT '0',
  `survival_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `survival_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `charisma` int(11) NOT NULL DEFAULT '0',
  `charisma_mod` int(11) NOT NULL DEFAULT '0',
  `charisma_save` int(11) NOT NULL DEFAULT '0',
  `charisma_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `deception` int(11) NOT NULL DEFAULT '0',
  `deception_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `deception_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `intimidation` int(11) NOT NULL DEFAULT '0',
  `intimidation_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `intimidation_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `performance` int(11) NOT NULL DEFAULT '0',
  `performance_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `performance_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `persuasion` int(11) NOT NULL DEFAULT '0',
  `persuasion_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `persuasion_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `skills_auto_filled` tinyint(1) NOT NULL DEFAULT '1',
  `skill_modifiers` json DEFAULT NULL,
  `spellcaster` tinyint(1) NOT NULL DEFAULT '0',
  `spell_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'slots',
  `spell_dc` int(11) DEFAULT NULL,
  `spell_level` int(11) DEFAULT NULL,
  `spell_points_max` int(11) DEFAULT NULL,
  `spell_points_current` int(11) DEFAULT NULL,
  `spell_recover` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'long',
  `spell_list_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'known',
  `spell_slots_1` json DEFAULT NULL,
  `spell_slots_2` json DEFAULT NULL,
  `spell_slots_3` json DEFAULT NULL,
  `spell_slots_4` json DEFAULT NULL,
  `spell_slots_5` json DEFAULT NULL,
  `spell_slots_6` json DEFAULT NULL,
  `spell_slots_7` json DEFAULT NULL,
  `spell_slots_8` json DEFAULT NULL,
  `spell_slots_9` json DEFAULT NULL,
  `spell_list_0` json DEFAULT NULL,
  `spell_list_1` json DEFAULT NULL,
  `spell_list_2` json DEFAULT NULL,
  `spell_list_3` json DEFAULT NULL,
  `spell_list_4` json DEFAULT NULL,
  `spell_list_5` json DEFAULT NULL,
  `spell_list_6` json DEFAULT NULL,
  `spell_list_7` json DEFAULT NULL,
  `spell_list_8` json DEFAULT NULL,
  `spell_list_9` json DEFAULT NULL,
  `spell_prepare_count` int(11) DEFAULT NULL,
  `spell_prepared` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `show_resources` tinyint(1) NOT NULL DEFAULT '1',
  `show_modifiers` tinyint(1) NOT NULL DEFAULT '1',
  `show_notes` tinyint(1) NOT NULL DEFAULT '1',
  `show_dice` tinyint(1) NOT NULL DEFAULT '1',
  `show_additional_stats` tinyint(1) NOT NULL DEFAULT '1',
  `show_temp_hp` tinyint(1) NOT NULL DEFAULT '1',
  `damage_vulnerabilities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_resistances` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_immunities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition_immunities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senses` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alignment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `challenge_rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `experience` int(11) DEFAULT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `encounter_id` bigint(20) unsigned NOT NULL,
  `weight` int(11) NOT NULL,
  `name_number` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `encounter_monsters_user_id_foreign` (`user_id`),
  KEY `encounter_monsters_encounter_id_foreign` (`encounter_id`),
  CONSTRAINT `encounter_monsters_encounter_id_foreign` FOREIGN KEY (`encounter_id`) REFERENCES `encounters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `encounter_monsters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter_monsters`
--

LOCK TABLES `encounter_monsters` WRITE;
/*!40000 ALTER TABLE `encounter_monsters` DISABLE KEYS */;
INSERT INTO `encounter_monsters` VALUES (21,'2021-11-21 03:39:20','2021-11-21 13:37:32',1,'Stirge',2,0,0,'[{\"size\": 4, \"count\": 1, \"current\": 1}]',14,'natural armor',3,'10 ft., fly 40 ft.',3,-4,-4,0,-4,0,0,16,3,3,0,3,0,0,3,0,0,3,0,0,11,0,0,0,2,-4,-4,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,8,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,6,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,NULL,NULL,'darkvision: 60 ft., passive Perception: 9','Tiny','Beast','Unaligned','1/8',15,'Monster Manual p284',3,2,0),(22,'2021-11-21 03:39:20','2021-11-21 13:40:46',1,'Stirge',2,0,0,'[{\"size\": 4, \"count\": 1, \"current\": 1}]',14,'natural armor',3,'10 ft., fly 40 ft.',3,-4,-4,0,-4,0,0,16,3,3,0,3,0,0,3,0,0,3,0,0,11,0,0,0,2,-4,-4,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,8,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,6,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,NULL,NULL,'darkvision: 60 ft., passive Perception: 9','Tiny','Beast','Unaligned','1/8',15,'Monster Manual p284',3,3,1),(23,'2021-11-21 03:39:21','2021-11-21 13:12:29',1,'Stirge',2,0,0,'[{\"size\": 4, \"count\": 1, \"current\": 1}]',14,'natural armor',3,'10 ft., fly 40 ft.',3,-4,-4,0,-4,0,0,16,3,3,0,3,0,0,3,0,0,3,0,0,11,0,0,0,2,-4,-4,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,8,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,6,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,NULL,NULL,'darkvision: 60 ft., passive Perception: 9','Tiny','Beast','Unaligned','1/8',15,'Monster Manual p284',3,4,2),(24,'2021-11-21 03:40:27','2021-11-21 03:40:27',1,'Kenku',13,13,0,'[{\"size\": 8, \"count\": 3, \"current\": 3}]',13,'-',3,'30 ft.',10,0,0,0,0,0,0,16,3,3,0,3,0,0,3,0,0,5,1,0,10,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,0,0,10,0,0,0,4,1,1,0,0,0,0,0,0,0,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ambusher: In the first round of combat, the kenku has advantage on attack rolls against any creature it surprised.\n\nMimicry: The kenku can mimic any sounds it has heard, including voices.  A creature that hears the sounds can tell they are imitations with a successful DC 14 Wisdom (Insight) check.',1,1,1,1,1,1,NULL,NULL,NULL,NULL,'understands Auran and Common but speaks only through the use of its Mimicry trait','passive Perception: 12','Medium','Humanoid (kenku)','Chaotic Neutral','1/4',50,'Monster Manual p194',4,1,0),(25,'2021-11-21 03:40:28','2021-11-21 03:40:28',1,'Kenku',13,13,0,'[{\"size\": 8, \"count\": 3, \"current\": 3}]',13,'-',3,'30 ft.',10,0,0,0,0,0,0,16,3,3,0,3,0,0,3,0,0,5,1,0,10,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,0,0,10,0,0,0,4,1,1,0,0,0,0,0,0,0,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ambusher: In the first round of combat, the kenku has advantage on attack rolls against any creature it surprised.\n\nMimicry: The kenku can mimic any sounds it has heard, including voices.  A creature that hears the sounds can tell they are imitations with a successful DC 14 Wisdom (Insight) check.',1,1,1,1,1,1,NULL,NULL,NULL,NULL,'understands Auran and Common but speaks only through the use of its Mimicry trait','passive Perception: 12','Medium','Humanoid (kenku)','Chaotic Neutral','1/4',50,'Monster Manual p194',4,2,1),(26,'2021-11-21 03:40:28','2021-11-21 03:40:28',1,'Kenku',13,13,0,'[{\"size\": 8, \"count\": 3, \"current\": 3}]',13,'-',3,'30 ft.',10,0,0,0,0,0,0,16,3,3,0,3,0,0,3,0,0,5,1,0,10,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,0,0,10,0,0,0,4,1,1,0,0,0,0,0,0,0,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ambusher: In the first round of combat, the kenku has advantage on attack rolls against any creature it surprised.\n\nMimicry: The kenku can mimic any sounds it has heard, including voices.  A creature that hears the sounds can tell they are imitations with a successful DC 14 Wisdom (Insight) check.',1,1,1,1,1,1,NULL,NULL,NULL,NULL,'understands Auran and Common but speaks only through the use of its Mimicry trait','passive Perception: 12','Medium','Humanoid (kenku)','Chaotic Neutral','1/4',50,'Monster Manual p194',4,3,2),(27,'2021-11-21 03:40:28','2021-11-21 03:40:28',1,'Kenku',13,13,0,'[{\"size\": 8, \"count\": 3, \"current\": 3}]',13,'-',3,'30 ft.',10,0,0,0,0,0,0,16,3,3,0,3,0,0,3,0,0,5,1,0,10,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,0,0,10,0,0,0,4,1,1,0,0,0,0,0,0,0,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ambusher: In the first round of combat, the kenku has advantage on attack rolls against any creature it surprised.\n\nMimicry: The kenku can mimic any sounds it has heard, including voices.  A creature that hears the sounds can tell they are imitations with a successful DC 14 Wisdom (Insight) check.',1,1,1,1,1,1,NULL,NULL,NULL,NULL,'understands Auran and Common but speaks only through the use of its Mimicry trait','passive Perception: 12','Medium','Humanoid (kenku)','Chaotic Neutral','1/4',50,'Monster Manual p194',4,4,3),(28,'2021-11-21 04:11:44','2021-11-21 13:51:02',1,'Merregon',45,1,0,'[{\"size\": 8, \"count\": 6, \"current\": 6}]',16,'natural armor',2,'30 ft.',18,4,4,0,4,0,0,14,2,2,0,2,0,0,2,0,0,2,0,0,17,3,3,0,6,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,12,1,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,8,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Devil\'s Sight: Magical darkness doesn\'t impede the merregon\'s darkvision.\n\nMagic Resistance: The merregon has advantage on saving throws against spells and other magical effects.\n\nMultiattack:  The meregon makes two halberd attacks, or if an allied fiend of challenge rating 6 or higher is within 60 feet of it, the merregon makes three halberd attacks.',1,1,1,1,1,1,NULL,'cold; bludgeoning, piercing, and slashing from nonmagical attacks that aren\'t silvered','fire, poison','frightened, poisoned','understands infernal but can\'t speak, telepathy 120 ft.','darkvision: 60 ft., passive Perception: 11','Medium','Fiend (devil)','Lawful Evil','4',1100,'Mordenkainen\'s Tome of Foes',3,1,0);
/*!40000 ALTER TABLE `encounter_monsters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounters`
--

DROP TABLE IF EXISTS `encounters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `encounters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `encounters_user_id_foreign` (`user_id`),
  CONSTRAINT `encounters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounters`
--

LOCK TABLES `encounters` WRITE;
/*!40000 ALTER TABLE `encounters` DISABLE KEYS */;
INSERT INTO `encounters` VALUES (3,'2021-11-21 03:39:10','2021-11-21 13:51:02',1,'Yawning Portal','42\n\ns3:dead\ns4:dead\ns5:dead'),(4,'2021-11-21 03:40:23','2021-11-21 03:40:23',1,'Zhentarim Hideout',NULL);
/*!40000 ALTER TABLE `encounters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (15,'2014_10_12_000000_create_users_table',1),(16,'2014_10_12_100000_create_password_resets_table',1),(17,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),(18,'2019_08_19_000000_create_failed_jobs_table',1),(19,'2019_12_14_000001_create_personal_access_tokens_table',1),(20,'2021_09_06_112227_create_sessions_table',1),(21,'2021_09_08_020140_create_characters_table',1),(22,'2021_09_21_234108_create_resources_table',1),(23,'2021_09_26_234927_create_modifiers_table',1),(24,'2021_10_05_012631_create_actions_table',1),(25,'2021_10_15_134755_create_monsters_table',1),(26,'2021_10_16_195019_create_encounters_table',1),(27,'2021_10_17_022349_create_encounter_monsters_table',1),(28,'2021_10_26_232146_create_dice_tables_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifiers`
--

DROP TABLE IF EXISTS `modifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modifiers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creature_id` bigint(20) unsigned NOT NULL,
  `creature_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ability` tinyint(1) NOT NULL DEFAULT '0',
  `ability_dice` json DEFAULT NULL,
  `save` tinyint(1) NOT NULL DEFAULT '0',
  `save_dice` json DEFAULT NULL,
  `attack` tinyint(1) NOT NULL DEFAULT '0',
  `attack_dice` json DEFAULT NULL,
  `critical_range` tinyint(1) NOT NULL DEFAULT '0',
  `critical_range_start` int(11) DEFAULT NULL,
  `damage` tinyint(1) NOT NULL DEFAULT '0',
  `damage_as` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_dc` int(11) DEFAULT NULL,
  `damage_save` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_dice` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifiers`
--

LOCK TABLES `modifiers` WRITE;
/*!40000 ALTER TABLE `modifiers` DISABLE KEYS */;
INSERT INTO `modifiers` VALUES (1,'2021-10-28 01:05:25','2021-11-14 14:46:19','Bless',1,'App\\Models\\Character',0,NULL,1,'[{\"size\": 4, \"count\": 1, \"modifier\": 0}]',1,'[{\"size\": 4, \"count\": 1, \"modifier\": 0}]',0,NULL,0,NULL,NULL,NULL,NULL,'You are blessed',0);
/*!40000 ALTER TABLE `modifiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monsters`
--

DROP TABLE IF EXISTS `monsters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monsters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hp_max` int(11) NOT NULL DEFAULT '0',
  `hp_current` int(11) NOT NULL DEFAULT '0',
  `hp_temp` int(11) NOT NULL DEFAULT '0',
  `hit_dice` json DEFAULT NULL,
  `ac` int(11) NOT NULL DEFAULT '0',
  `ac_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initiative` int(11) NOT NULL DEFAULT '0',
  `speed` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `strength` int(11) NOT NULL DEFAULT '0',
  `strength_mod` int(11) NOT NULL DEFAULT '0',
  `strength_save` int(11) NOT NULL DEFAULT '0',
  `strength_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `athletics` int(11) NOT NULL DEFAULT '0',
  `athletics_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `athletics_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `dexterity` int(11) NOT NULL DEFAULT '0',
  `dexterity_mod` int(11) NOT NULL DEFAULT '0',
  `dexterity_save` int(11) NOT NULL DEFAULT '0',
  `dexterity_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `acrobatics` int(11) NOT NULL DEFAULT '0',
  `acrobatics_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `acrobatics_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `sleight_of_hand` int(11) NOT NULL DEFAULT '0',
  `sleight_of_hand_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `sleight_of_hand_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `stealth` int(11) NOT NULL DEFAULT '0',
  `stealth_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `stealth_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `constitution` int(11) NOT NULL DEFAULT '0',
  `constitution_mod` int(11) NOT NULL DEFAULT '0',
  `constitution_save` int(11) NOT NULL DEFAULT '0',
  `constitution_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `intelligence` int(11) NOT NULL DEFAULT '0',
  `intelligence_mod` int(11) NOT NULL DEFAULT '0',
  `intelligence_save` int(11) NOT NULL DEFAULT '0',
  `intelligence_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `arcana` int(11) NOT NULL DEFAULT '0',
  `arcana_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `arcana_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `history` int(11) NOT NULL DEFAULT '0',
  `history_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `history_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `investigation` int(11) NOT NULL DEFAULT '0',
  `investigation_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `investigation_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `nature` int(11) NOT NULL DEFAULT '0',
  `nature_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `nature_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `religion` int(11) NOT NULL DEFAULT '0',
  `religion_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `religion_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `wisdom` int(11) NOT NULL DEFAULT '0',
  `wisdom_mod` int(11) NOT NULL DEFAULT '0',
  `wisdom_save` int(11) NOT NULL DEFAULT '0',
  `wisdom_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `animal_handling` int(11) NOT NULL DEFAULT '0',
  `animal_handling_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `animal_handling_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `insight` int(11) NOT NULL DEFAULT '0',
  `insight_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `insight_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `medicine` int(11) NOT NULL DEFAULT '0',
  `medicine_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `medicine_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `perception` int(11) NOT NULL DEFAULT '0',
  `perception_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `perception_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `survival` int(11) NOT NULL DEFAULT '0',
  `survival_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `survival_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `charisma` int(11) NOT NULL DEFAULT '0',
  `charisma_mod` int(11) NOT NULL DEFAULT '0',
  `charisma_save` int(11) NOT NULL DEFAULT '0',
  `charisma_save_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `deception` int(11) NOT NULL DEFAULT '0',
  `deception_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `deception_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `intimidation` int(11) NOT NULL DEFAULT '0',
  `intimidation_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `intimidation_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `performance` int(11) NOT NULL DEFAULT '0',
  `performance_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `performance_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `persuasion` int(11) NOT NULL DEFAULT '0',
  `persuasion_proficiency` tinyint(1) NOT NULL DEFAULT '0',
  `persuasion_expertise` tinyint(1) NOT NULL DEFAULT '0',
  `skills_auto_filled` tinyint(1) NOT NULL DEFAULT '1',
  `skill_modifiers` json DEFAULT NULL,
  `spellcaster` tinyint(1) NOT NULL DEFAULT '0',
  `spell_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'slots',
  `spell_dc` int(11) DEFAULT NULL,
  `spell_level` int(11) DEFAULT NULL,
  `spell_points_max` int(11) DEFAULT NULL,
  `spell_points_current` int(11) DEFAULT NULL,
  `spell_recover` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'long',
  `spell_list_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'known',
  `spell_slots_1` json DEFAULT NULL,
  `spell_slots_2` json DEFAULT NULL,
  `spell_slots_3` json DEFAULT NULL,
  `spell_slots_4` json DEFAULT NULL,
  `spell_slots_5` json DEFAULT NULL,
  `spell_slots_6` json DEFAULT NULL,
  `spell_slots_7` json DEFAULT NULL,
  `spell_slots_8` json DEFAULT NULL,
  `spell_slots_9` json DEFAULT NULL,
  `spell_list_0` json DEFAULT NULL,
  `spell_list_1` json DEFAULT NULL,
  `spell_list_2` json DEFAULT NULL,
  `spell_list_3` json DEFAULT NULL,
  `spell_list_4` json DEFAULT NULL,
  `spell_list_5` json DEFAULT NULL,
  `spell_list_6` json DEFAULT NULL,
  `spell_list_7` json DEFAULT NULL,
  `spell_list_8` json DEFAULT NULL,
  `spell_list_9` json DEFAULT NULL,
  `spell_prepare_count` int(11) DEFAULT NULL,
  `spell_prepared` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `show_resources` tinyint(1) NOT NULL DEFAULT '1',
  `show_modifiers` tinyint(1) NOT NULL DEFAULT '1',
  `show_notes` tinyint(1) NOT NULL DEFAULT '1',
  `show_dice` tinyint(1) NOT NULL DEFAULT '1',
  `show_additional_stats` tinyint(1) NOT NULL DEFAULT '1',
  `show_temp_hp` tinyint(1) NOT NULL DEFAULT '1',
  `damage_vulnerabilities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_resistances` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `damage_immunities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition_immunities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senses` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alignment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `challenge_rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `experience` int(11) DEFAULT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `monsters_user_id_foreign` (`user_id`),
  CONSTRAINT `monsters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monsters`
--

LOCK TABLES `monsters` WRITE;
/*!40000 ALTER TABLE `monsters` DISABLE KEYS */;
INSERT INTO `monsters` VALUES (1,'2021-10-28 01:05:25','2021-11-14 14:52:59',1,'Wolf',11,11,0,'[{\"size\": 8, \"count\": 2, \"current\": 2}]',13,'natural armor',2,'40 ft.',12,1,1,0,1,0,0,15,2,2,0,2,0,0,2,0,0,4,1,0,12,1,1,0,3,-4,-4,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,-4,0,0,12,1,1,0,1,0,0,1,0,0,1,0,0,3,1,0,1,0,0,6,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Keen Hearing and Smell: The wold has advantage on Wisdom (Perception) checks that rely on hearing or smell.\n\nPack Tactics: The wolf has advantage on an attack roll against a creature if at least one of the wolf\'s allies is within 5 feet of the creature and the ally isn\'t incapacitated.',0,0,1,0,1,1,NULL,NULL,NULL,NULL,NULL,'passive Perception: 13','Medium','Beast','unaligned','1/4',50,'Monster Manual p341',1),(2,'2021-11-21 03:20:18','2021-11-21 03:24:08',1,'Troll',84,84,0,'[{\"size\": 10, \"count\": 8, \"current\": 8}]',15,'natural armor',1,'30 ft.',18,4,4,0,4,0,0,13,1,1,0,1,0,0,1,0,0,1,0,0,20,5,5,0,7,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,9,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,2,1,0,-1,0,0,7,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Keen Smell: The troll has advantage on Wisdom (Perception) checks that rely on smell.\n\nRegeneration: The troll regains 10 hit points at the start of its turns.  If the troll takes acid or fire damage, this trait doesn\'t function at the start of the troll\'s next turn.  The troll dies only if it starts its turn with 0 hit points and doesn\'t regenerate.\n\nMultiattack: The troll makes three attacks: one with its bite and two with its claws.',1,1,1,1,1,1,NULL,NULL,NULL,NULL,'Giant','darkvision: 60 ft., passive Perception: 12','Large','Giant','Chaotic Evil','5',1800,'Monster Manual p291',1),(4,'2021-11-21 03:31:58','2021-11-21 03:33:50',1,'Kenku',13,13,0,'[{\"size\": 8, \"count\": 3, \"current\": 3}]',13,'-',3,'30 ft.',10,0,0,0,0,0,0,16,3,3,0,3,0,0,3,0,0,5,1,0,10,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,0,0,10,0,0,0,4,1,1,0,0,0,0,0,0,0,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ambusher: In the first round of combat, the kenku has advantage on attack rolls against any creature it surprised.\n\nMimicry: The kenku can mimic any sounds it has heard, including voices.  A creature that hears the sounds can tell they are imitations with a successful DC 14 Wisdom (Insight) check.',1,1,1,1,1,1,NULL,NULL,NULL,NULL,'understands Auran and Common but speaks only through the use of its Mimicry trait','passive Perception: 12','Medium','Humanoid (kenku)','Chaotic Neutral','1/4',50,'Monster Manual p194',1),(5,'2021-11-21 03:37:02','2021-11-21 03:38:18',1,'Goblin',7,7,0,'[{\"size\": 6, \"count\": 2, \"current\": 2}]',15,'leather armor, shield',2,'30 ft.',8,-1,-1,0,-1,0,0,14,2,2,0,2,0,0,2,0,0,6,1,1,10,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,8,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nimble Escape: The goblin can take the Disengage or Hide action as a bonus action on each of its turns.',1,1,1,1,1,1,NULL,NULL,NULL,NULL,'Common, Goblin','darkvision: 60 ft., passive Perception: 9','Small','Humanoid (goblinoid)','Neutral Evil','1/4',50,'Monster Manual p166',1),(6,'2021-11-21 04:03:48','2021-11-21 04:06:39',1,'Merregon',45,45,0,'[{\"size\": 8, \"count\": 6, \"current\": 6}]',16,'natural armor',2,'30 ft.',18,4,4,0,4,0,0,14,2,2,0,2,0,0,2,0,0,2,0,0,17,3,3,0,6,-2,-2,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,-2,0,0,12,1,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,8,-1,-1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,1,'[]',0,'slots',NULL,NULL,NULL,NULL,'long','known','[]','[]','[]','[]','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Devil\'s Sight: Magical darkness doesn\'t impede the merregon\'s darkvision.\n\nMagic Resistance: The merregon has advantage on saving throws against spells and other magical effects.\n\nMultiattack:  The meregon makes two halberd attacks, or if an allied fiend of challenge rating 6 or higher is within 60 feet of it, the merregon makes three halberd attacks.',1,1,1,1,1,1,NULL,'cold; bludgeoning, piercing, and slashing from nonmagical attacks that aren\'t silvered','fire, poison','frightened, poisoned','understands infernal but can\'t speak, telepathy 120 ft.','darkvision: 60 ft., passive Perception: 11','Medium','Fiend (devil)','Lawful Evil','4',1100,'Mordenkainen\'s Tome of Foes',1);
/*!40000 ALTER TABLE `monsters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creature_id` bigint(20) unsigned NOT NULL,
  `creature_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `counter_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `current` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slots` json DEFAULT NULL,
  `recover` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dice` json DEFAULT NULL,
  `dice_table_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` VALUES (1,'2021-10-28 01:05:25','2021-11-22 14:23:56','Bardic Insp',1,'App\\Models\\Character','counter','slots',4,'4','[false, false, false, false]','long',NULL,NULL),(4,'2021-10-30 11:20:36','2021-11-22 13:27:15','Icethorn Entangle (DC 14)',1,'App\\Models\\Character','counter','slots',1,'1','[false]','long','[{\"size\": null, \"count\": null, \"modifier\": null}]',NULL),(5,'2021-11-22 13:27:34','2021-11-22 13:27:34','Icethorn Restrain (DC 14)',1,'App\\Models\\Character','counter','slots',1,'1','[false]','long','[{\"size\": null, \"count\": null, \"modifier\": null}]',NULL),(6,'2021-11-22 13:27:48','2021-11-22 13:27:48','Icethorn Spike Growth (DC 14)',1,'App\\Models\\Character','counter','slots',1,'1','[false]','long','[{\"size\": null, \"count\": null, \"modifier\": null}]',NULL);
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('73oGQP6iqEltU80Al2Rpipc3AwZnbZPlXDUOeojs',NULL,'172.19.0.2','axios/0.21.4','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlRCVHJZbkNxZ3ZzNlVFeDZ2aUFuN1I4TDNHSm40Tk4ycFlhRHNTNSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8venRvb2xzLnRlc3QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1637579132),('F1jtVlw64QJUaJtcEqPQsRlbO1DhRp3VRdQMLmQL',NULL,'172.19.0.1','axios/0.21.4','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkVKTnJHMmRrSmpGSE5EdlVDYW4wb0phMTFEVXJadVl1ck85OWhObyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vbG9jYWxob3N0OjQ5MTU4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1637579132),('KT8fqYzKgxhfte9CrQHR4siGzSWDCB43Zz2pUbKZ',NULL,'172.19.0.1','axios/0.21.4','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVm9yTk5QS2FxYXN3bVRMTVUyS3UwdXM4QW9DR3Q4SEpqbm9LTnBiMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9sb2NhbGhvc3Q6NDkxNTkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1637579132),('N7CJLJPZb5eX88KfQPjXS32qWJhVlXpu8nJGECVt',NULL,'172.19.0.2','axios/0.21.4','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVpWc210TTZ1VjRNNUh5UU9rSG5zZUk1dTAxcE9YdTVFU3NxUlVHdyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTg6Imh0dHA6Ly96dG9vbHMudGVzdCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1637579132),('zqh9flzzMwzmGQvsAdbn0qD0sxEJuSB9whbSlM1P',1,'172.19.0.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0','YTo2OntzOjY6Il90b2tlbiI7czo0MDoic1VnQWQxZVpobHlvNXdCUVhHREZNem1VWXNweVJtd21zbGpOdVNGcSI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJGZ5MVVIU01qRWs0MUlVeFJMMUJGME9HQ00uc3RxOE1rQjIzZU1hTmZmNFh3SnV0WmFxMldXIjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRmeTFVSFNNakVrNDFJVXhSTDFCRjBPR0NNLnN0cThNa0IyM2VNYU5mZjRYd0p1dFphcTJXVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly96dG9vbHMudGVzdC9jaGFyYWN0ZXJzLzEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1637591947);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'light',
  `font` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `party` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'test','test@example.com','2021-10-28 01:05:25','$2y$10$fy1UHSMjEk41IUxRL1BF0OGCM.stq8MkB23eMaNff4XwJutZaq2WW',NULL,NULL,'q2JboX87pq',NULL,NULL,'dark','default',1,'[{\"count\": 3, \"level\": 1}]','2021-10-28 01:05:25','2021-11-21 03:39:01'),(2,'Ms. Cortney Jones','harmon47@example.org','2021-10-28 01:05:25','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'7LpQ8ZosSX',NULL,NULL,'light','default',0,NULL,'2021-10-28 01:05:25','2021-10-28 01:05:25'),(3,'Florine Lemke','jess.green@example.net','2021-10-28 01:05:25','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'7UpOr363ex',NULL,NULL,'light','default',0,NULL,'2021-10-28 01:05:25','2021-10-28 01:05:25'),(4,'Mrs. Neha Bins','huels.sherman@example.net','2021-10-28 01:05:25','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'O66QYT2fi4',NULL,NULL,'light','default',0,NULL,'2021-10-28 01:05:25','2021-10-28 01:05:25'),(5,'Prof. Bailey Ratke Sr.','oconnell.marlee@example.net','2021-10-28 01:05:26','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'ejUOuc0DYW',NULL,NULL,'light','default',0,NULL,'2021-10-28 01:05:26','2021-10-28 01:05:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-22 15:11:32
